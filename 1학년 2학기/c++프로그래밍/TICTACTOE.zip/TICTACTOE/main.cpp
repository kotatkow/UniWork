#include <iostream>

using namespace std;

class TICTACTOE{

public:

string slot[9]={"1","2","3","4","5","6","7","8","9"};
bool OW=0, XW=0;
bool D=0;
int select;
int selCounter=0;
string shape;
bool cmp=0;

void StartingShape(){

    while(shape!="O"&&shape!="X"){

        cout<<"choose starting shape(X or O): ";
        getline(cin, shape);

        if(shape!="O"&&shape!="X"){
            cout<<"Enter Captial 'X' or 'O'"<<endl;
        }
    };
}

void Grid(){

cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"  "<<slot[0]<<"  "<<"|"<<"  "<<slot[1]<<"   "<<"|"<<"  "<<slot[2]<<"  "<<endl;
cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"------------------"<<endl;
cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"  "<<slot[3]<<"  "<<"|"<<"  "<<slot[4]<<"   "<<"|"<<"  "<<slot[5]<<"  "<<endl;
cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"------------------"<<endl;
cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"  "<<slot[6]<<"  "<<"|"<<"  "<<slot[7]<<"   "<<"|"<<"  "<<slot[8]<<"  "<<endl;
cout<<"     "<<"|"<<"      "<<"|"<<"      "<<endl;
cout<<"------------------"<<endl;


};



void WinOrLose(){

if(slot[0]==slot[1]&&slot[1]==slot[2]){
        if(slot[0]=="O"){
            OW=1;
        }else if(slot[0]=="X"){
            XW=1;
        };
        }else if(slot[3]==slot[4]&&slot[4]==slot[5]){
        if(slot[3]=="O"){
            OW=1;
        }else if(slot[3]=="X"){
            XW=1;
        };
    }else if(slot[6]==slot[7]&&slot[7]==slot[8]){
        if(slot[6]=="O"){
            OW=1;
        }else if(slot[6]=="X"){
            XW=1;
        };

    }else if(slot[2]==slot[4]&&slot[4]==slot[6]){
        if(slot[2]=="O"){
            OW=1;
        }else if(slot[2]=="X"){
            XW=1;
        };
    }else if(slot[0]==slot[4]&&slot[4]==slot[8]){
        if(slot[0]=="O"){
            OW=1;
        }else if(slot[0]=="X"){
            XW=1;
        };

    }else if(slot[0]==slot[3]&&slot[3]==slot[6]){
        if(slot[3]=="O"){
            OW=1;
        }else if(slot[3]=="X"){
            XW=1;
        };

    }else if(slot[1]==slot[4]&&slot[4]==slot[7]){
        if(slot[1]=="O"){
            OW=1;
        }else if(slot[1]=="X"){
            XW=1;
        };

    }else if(slot[2]==slot[5]&&slot[5]==slot[8]){
        if(slot[2]=="O"){
            OW=1;
        }else if(slot[2]=="X"){
            XW=1;
        };

    }else{
       if(selCounter==9){
       D=1;
       };

    };

};

void Select(){

    if(cmp){

        cout<<"Choose a different slot"<<endl;

    }

    cout<<"Enter slot number: ";
    cin>>select;



}

void Change(int aChange){


    if (slot[aChange-1]=="X"||slot[aChange-1]=="O"){

        cmp=1;

    }else{
        cmp=0;
    }

    if(slot[aChange-1]!="X"&&slot[aChange-1]!="O"){
        slot[aChange-1]=shape;
        selCounter++;

        if(shape=="O"){
            shape="X";
        }else{
            shape="O";
        }
    };


};

};





int main(){

int a=0;
string confirm;
TICTACTOE tic;

tic.StartingShape();

cout<<"====GAME START===="<<endl;

while(tic.XW==0&&tic.OW==0&&tic.D==0){

    cout<<tic.shape<<"'s turn"<<endl;

    tic.Grid();
    tic.Select();
    tic.Change(tic.select);
    tic.WinOrLose();

    cout<<"=============================="<<endl;

};

cout<<"=============================="<<endl;
cout<<"=============================="<<endl;
cout<<"<<Final Result>>"<<endl;

tic.Grid();

if(tic.XW){
    cout<<"Winner: X"<<endl;
    cout<<"Winner: X"<<endl;
    cout<<"Winner: X"<<endl;
}else if(tic.OW){
    cout<<"Winner: O"<<endl;
    cout<<"Winner: O"<<endl;
    cout<<"Winner: O"<<endl;
}else{
    cout<<"DRAW"<<endl;
    cout<<"DRAW"<<endl;
    cout<<"DRAW"<<endl;
}


return 0;
}
